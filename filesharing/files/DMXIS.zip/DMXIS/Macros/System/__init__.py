#===============================================================
# DMXIS Startup Macro (c) 2010 db audioware limited
#
# This is called on DMXIS startup, and initialises any global
# Python requirements across all macros 
#===============================================================

import _DmxApi
from _DmxApi import *
